﻿namespace Pay1193.Entity
{
    public enum StudentLoan
    {
        Yes,
        No
    }
}