﻿namespace Pay1193.Models
{
    public class EmployeeDeleteViewModel
    {
        public int Id { get; set; }
        public string FullName { get; set; }
    }
}
